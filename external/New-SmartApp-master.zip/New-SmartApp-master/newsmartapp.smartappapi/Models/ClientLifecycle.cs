﻿namespace NewSmartApp.Webservice.Models
{
    public class ClientLifecycle : LifecycleBase
    {
        public Client Client { get; set; }
    }
}
