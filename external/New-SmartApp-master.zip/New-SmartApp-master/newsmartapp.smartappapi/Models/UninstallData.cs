﻿namespace NewSmartApp.Webservice.Models
{
    public class UninstallData
    {
        public InstalledApp InstalledApp { get; set; }
        public object Settings { get; set; }
    }
}