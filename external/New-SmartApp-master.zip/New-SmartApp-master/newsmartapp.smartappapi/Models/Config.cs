﻿namespace NewSmartApp.Webservice.Models
{
    public class Config
    {
        public string ValueType { get; set; }
    }
}
