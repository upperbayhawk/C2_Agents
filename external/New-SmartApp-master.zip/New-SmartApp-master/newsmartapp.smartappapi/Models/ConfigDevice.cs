﻿namespace NewSmartApp.Webservice.Models
{
    public class ConfigDevice : Config
    {
        public DeviceConfig DeviceConfig { get; set; }
    }
}
