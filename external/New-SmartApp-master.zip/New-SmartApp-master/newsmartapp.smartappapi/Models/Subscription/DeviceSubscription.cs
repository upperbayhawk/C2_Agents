﻿namespace NewSmartApp.Webservice.Models.Subscription
{
    public class DeviceSubscription : Subscription
    {
        public DeviceSubscriptionInfo device { get; set; }
    }
}