﻿namespace NewSmartApp.Webservice.Models.Subscription
{
    public abstract class Subscription
    {
        public string sourceType { get; set; }
    }
}