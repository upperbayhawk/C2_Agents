﻿namespace NewSmartApp.Webservice.Models
{
    public class TimerEvent
    {
        public string EventId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Time { get; set; }
        public string Expression { get; set; }
    }
}