﻿namespace NewSmartApp.Webservice.Models
{
    public class Client
    {
        public string OS { get; set; }
        public string Version { get; set; }
        public string Language { get; set; }
    }
}
