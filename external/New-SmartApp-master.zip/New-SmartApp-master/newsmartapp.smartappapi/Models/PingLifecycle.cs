﻿namespace NewSmartApp.Webservice.Models
{
    public class PingLifecycle : LifecycleBase
    {
        public PingData PingData { get; set; }
    }
}