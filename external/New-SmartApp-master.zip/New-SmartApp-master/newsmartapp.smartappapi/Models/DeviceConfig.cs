﻿using System;

namespace NewSmartApp.Webservice.Models
{
    public class DeviceConfig
    {
        public Guid DeviceId { get; set; }
        public string ComponentId { get; set; }
    }
}
