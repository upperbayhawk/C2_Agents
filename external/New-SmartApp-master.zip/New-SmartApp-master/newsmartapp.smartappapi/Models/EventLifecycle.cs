﻿namespace NewSmartApp.Webservice.Models
{
    public class EventLifecycle : LifecycleBase
    {
        public EventData EventData { get; set; }
        public object Settings { get; set; }
    }
}