﻿using System;

namespace NewSmartApp.Webservice.Models
{

    public class PingData
    {
        public Guid Challenge { get; set; }
    }
}

