﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class ConfigurationInitializationResponse
    {
        public ConfigurationInitializationData ConfigurationData { get; set; }
    }
}
