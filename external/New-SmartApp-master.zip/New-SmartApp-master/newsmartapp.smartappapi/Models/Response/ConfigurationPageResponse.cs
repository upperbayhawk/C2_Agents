﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class ConfigurationPageResponse
    {
        public ConfigurationPageData ConfigurationData { get; set; }
    }
}