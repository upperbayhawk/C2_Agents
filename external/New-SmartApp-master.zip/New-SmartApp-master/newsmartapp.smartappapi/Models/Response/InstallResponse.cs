﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class InstallResponse
    {
        public object InstallData => new object();
    }
}
