﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class ConfigurationPageData
    {
        public ConfigurationPage Page { get; set; }
    }
}