﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class UpdateResponse
    {
        public object UpdateData => new object();
    }
}
