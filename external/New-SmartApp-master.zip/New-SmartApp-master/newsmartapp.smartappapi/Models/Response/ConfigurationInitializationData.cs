﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class ConfigurationInitializationData
    {
        public InitializationData Initialize { get; set; }
    }
}