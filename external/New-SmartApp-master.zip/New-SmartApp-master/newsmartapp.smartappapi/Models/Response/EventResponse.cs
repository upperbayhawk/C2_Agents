﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class EventResponse
    {
        public object EventData => new object();
    }
}
