﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class UninstallResponse
    {
        public object UninstallData => new object();
    }
}
