﻿namespace NewSmartApp.Webservice.Models.Response
{
    public class PingResponse
    {
        public PingData PingData { get; set; }
    }
}
