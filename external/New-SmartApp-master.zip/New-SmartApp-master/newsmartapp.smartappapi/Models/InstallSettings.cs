﻿namespace NewSmartApp.Webservice.Models
{
    public class InstallSettings
    {
        public string Property1 { get; set; }
        public string Property2 { get; set; }
    }
}