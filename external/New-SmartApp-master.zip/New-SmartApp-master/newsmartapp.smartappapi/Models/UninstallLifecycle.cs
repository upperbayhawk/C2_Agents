﻿namespace NewSmartApp.Webservice.Models
{
    public class UninstallLifecycle : LifecycleBase
    {
        public UninstallData UninstallData { get; set; }
        public object Settings { get; set; }
    }
}
