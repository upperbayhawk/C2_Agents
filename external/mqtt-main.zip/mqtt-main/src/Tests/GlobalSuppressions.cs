﻿using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Usage", "xUnit1000:Test classes must be public", Justification = "We use internal types as data for theory tests")]
