﻿namespace System.Net.Mqtt.Sdk
{
	internal interface IPacketIdProvider
	{
		ushort GetPacketId ();
	}
}
