﻿namespace System.Net.Mqtt.Sdk.Storage
{
	internal interface IStorageObject
	{
		string Id { get; }
	}
}
