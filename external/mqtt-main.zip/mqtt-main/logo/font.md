Logo made with Kaushan Script, 1 Style by Pablo Impallari
 from Google Fonts